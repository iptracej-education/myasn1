/********************************************************************

  sizeofBoolean function
  Last Modified: 9th October 2000
*********************************************************************/

int sizeofBoolean()
{
  int TYPE = 1;int LENGTH = 1;int VALUE = 1;
  return TYPE + LENGTH + VALUE;
}
